package com.example.werkstuk.db.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Merk {

    @PrimaryKey(autoGenerate = true)
    private int merkId;
    private String merkNaam;
    private String slogan;
    private int merkFoto;

    public int getMerkId() { return merkId; }

    public void setMerkId(int merkId) { this.merkId = merkId; }

    public String getMerkNaam() {
        return merkNaam;
    }

    public void setMerkNaam(String merkNaam) {
        this.merkNaam = merkNaam;
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    public int getMerkFoto() {
        return merkFoto;
    }

    public void setMerkFoto(int merkFoto) {
        this.merkFoto = merkFoto;
    }

    public Merk(int merkId, String merkNaam, String slogan, int merkFoto) {
        this.merkId = merkId;
        this.merkNaam = merkNaam;
        this.slogan = slogan;
        this.merkFoto = merkFoto;
    }

    @Ignore
    public Merk(){

    }
}
