package com.example.werkstuk.db.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.werkstuk.db.entities.Model;

import java.util.List;

@Dao
public interface ModelDao {

    @Query("SELECT * FROM Model")
    public List<Model> getAlleModellen();

    @Query("SELECT * FROM Model WHERE id =:id")
    public List<Model> getModelById(int id);

    @Query("SELECT * FROM Model m,Merk me WHERE m.merkId = me.merkId AND m.merkId =:merkId")
    public List<Model> getAlleModellenBijGekozenMerk(int merkId);

    @Query("SELECT * FROM Model WHERE modelType LIKE :modelType")
    public List<Model> getModelBijModeltype(String modelType);

    @Insert
    public long voegNieuwModelToe(Model nieuwModel);

}
