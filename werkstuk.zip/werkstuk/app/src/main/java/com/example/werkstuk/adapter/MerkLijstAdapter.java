package com.example.werkstuk.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import com.example.werkstuk.R;
import com.example.werkstuk.db.entities.Merk;

public class MerkLijstAdapter extends ArrayAdapter<Merk> {
        public MerkLijstAdapter (Context context, List<Merk> objects) {
                super(context, -1, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                LayoutInflater mijnLayoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View mijnListViewItemView = mijnLayoutInflater.inflate(R.layout.merklistitem, parent, false);

                //TextView lblMerkId = (TextView)mijnListViewItemView.findViewById(R.id.lblMerkId);
                TextView lblMerk = (TextView)mijnListViewItemView.findViewById(R.id.lblMerk);
                TextView lblSlogan = (TextView)mijnListViewItemView.findViewById(R.id.lblSlogan);
                ImageView imageViewMerk = (ImageView) mijnListViewItemView.findViewById(R.id.imageViewMerk);

                Merk weerTeGevenMerk = this.getItem(position);

                //lblMerkId.setText(Integer.toString(weerTeGevenMerk.getMerkId()));
                lblMerk.setText(weerTeGevenMerk.getMerkNaam());
                lblSlogan.setText(weerTeGevenMerk.getSlogan());
                imageViewMerk.setImageResource(weerTeGevenMerk.getMerkFoto());

                return mijnListViewItemView;
        }
}