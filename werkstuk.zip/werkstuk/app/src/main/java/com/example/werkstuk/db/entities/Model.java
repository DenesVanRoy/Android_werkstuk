package com.example.werkstuk.db.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(foreignKeys = @ForeignKey(entity = Merk.class, parentColumns = "merkId", childColumns = "merkId"))
public class Model {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String modelType;
    private String uitrusting;
    @ColumnInfo(name = "merkId")
    private int merkId;
    private int foto;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getUitrusting() {
        return uitrusting;
    }

    public void setUitrusting(String uitrusting) {
        this.uitrusting = uitrusting;
    }

    public int getMerkId() {
        return merkId;
    }

    public void setMerkId(int merkId) {
        this.merkId = merkId;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public Model(int id, String modelType, String uitrusting, int merkId, int foto) {
        this.id = id;
        this.modelType = modelType;
        this.uitrusting = uitrusting;
        this.merkId = merkId;
        this.foto = foto;
    }

    @Ignore
    public Model(){

    }
}
