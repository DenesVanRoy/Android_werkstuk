package com.example.werkstuk;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.werkstuk.adapter.AutogarageLijstAdapter;
import com.example.werkstuk.db.ApplicatieDatabase;
import com.example.werkstuk.db.entities.Autogarage;

import java.util.List;

public class Navigatiepagina extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.navigatiepagina);


        final Button ontdekOnzeMerken = (Button) findViewById(R.id.btnMerken);
        final Button zoekJouwDroomauto = (Button) findViewById(R.id.btnZoek);
        final Button bellen = (Button) findViewById(R.id.btnBellen);
        final Button emailen = (Button) findViewById(R.id.btnMailen);
        Thread mijnThread = new Thread(new Runnable() {

            @Override
            public void run() {


                //Lezen
                List<Autogarage> alleAutogarages = ApplicatieDatabase.getDatabase(Navigatiepagina.super.getApplicationContext()).getAutogarageDao().getAlleAutogarages();

                for (Autogarage huidigeAutogarage : alleAutogarages) {
                    Log.d("Autogarage naam: ", huidigeAutogarage.getNaam());
                }

                vullijstop(alleAutogarages);
            }
        });
        mijnThread.start();


        ontdekOnzeMerken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gaNaarDeMerkenPagina();
            }
        });

        zoekJouwDroomauto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gaNaarDeZoekPagina();
            }
        });


        bellen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:0412334567"));
                startActivity(intent);
            }
        });

        emailen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                Intent chooser = null;
                intent.setData(Uri.parse("mailto:"));
                String[] to = {"denes.van.roy@student.ehb.be"};
                intent.putExtra(Intent.EXTRA_EMAIL, to);
                intent.putExtra(Intent.EXTRA_SUBJECT, "Aankopen wagen");
                intent.setType("message/rfc822");
                chooser = Intent.createChooser(intent, "Verzend email");
                startActivity(chooser);
            }
        });


    }

    public void gaNaarDeMerkenPagina() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void gaNaarDeZoekPagina() {
        Intent intent = new Intent(this, Zoekpagina.class);
        startActivity(intent);
    }

    public void vullijstop(final List<Autogarage> alleAutogarages) {

        AutogarageLijstAdapter mijnGarageAdapter = new AutogarageLijstAdapter(this, alleAutogarages);
        ListView mijnLijst = findViewById(R.id.lstAutogarages);
        mijnLijst.setAdapter(mijnGarageAdapter);
    }
}