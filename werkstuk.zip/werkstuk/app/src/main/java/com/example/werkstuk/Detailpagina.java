package com.example.werkstuk;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.werkstuk.adapter.DetailLijstAdapter;
import com.example.werkstuk.db.ApplicatieDatabase;
import com.example.werkstuk.db.entities.Model;

import java.util.List;

public class Detailpagina extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detailpagina);

        Thread mijnThread = new Thread(new Runnable() {

            @Override
            public void run() {

                Bundle x = getIntent().getExtras();
                int id = x.getInt("id");
                Log.d("ModelId detail", x.toString());

                //Lezen
                List<Model> hetModel = ApplicatieDatabase.getDatabase(Detailpagina.super.getApplicationContext()).getModelDao().getModelById(id);

                for (Model huidigModel : hetModel) {
                    Log.d("Modeltypes detail: ", huidigModel.getModelType());
                    Log.d("ModelId detailpagina: ",String.valueOf(huidigModel.getId()));
                }
                vullijstop(hetModel);
            }
        });
        mijnThread.start();
    }

    public void vullijstop(List<Model> hetModel){
        DetailLijstAdapter mijnAdapter = new DetailLijstAdapter(this,hetModel);
        ListView mijnLijst = findViewById(R.id.lstDetails);
        mijnLijst.setAdapter(mijnAdapter);
    }
}
