package com.example.werkstuk.db.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Autogarage {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String naam;
    private int telefoonnummer;
    private String adres;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaam() {
        return naam;
    }

    public void setNaam(String naam) {
        this.naam = naam;
    }

    public int getTelefoonnummer() {
        return telefoonnummer;
    }

    public void setTelefoonnummer(int telefoonnummer) {
        this.telefoonnummer = telefoonnummer;
    }

    public String getAdres() {
        return adres;
    }

    public void setAdres(String adres) {
        this.adres = adres;
    }

    public Autogarage() {

    }

    @Ignore
    public Autogarage(int id, String naam, int telefoonnummer, String adres) {
        this.id = id;
        this.naam = naam;
        this.telefoonnummer = telefoonnummer;
        this.adres = adres;
    }
}
