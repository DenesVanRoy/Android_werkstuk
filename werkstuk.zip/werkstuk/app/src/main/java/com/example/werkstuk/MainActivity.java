package com.example.werkstuk;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.werkstuk.adapter.MerkLijstAdapter;
import com.example.werkstuk.adapter.ModelLijstAdapter;
import com.example.werkstuk.db.ApplicatieDatabase;
import com.example.werkstuk.db.entities.Merk;
import com.example.werkstuk.db.entities.Model;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Thread mijnThread = new Thread(new Runnable() {
            @Override
            public void run() {

                List<Merk> alleMerken = ApplicatieDatabase.getDatabase(MainActivity.super.getApplicationContext()).getMerkDao().getAlleMerken();

                for (Merk huidigMerk : alleMerken) {
                    Log.d("Database lezen", huidigMerk.getMerkNaam());

                }

                vullijstop(alleMerken);
            }
        });
        mijnThread.start();
    }

    public void vullijstop(final List<Merk> alleMerken){
        MerkLijstAdapter mijnAdapter = new MerkLijstAdapter(this,alleMerken);
        ListView mijnLijst = findViewById(R.id.lstMerken);
        mijnLijst.setAdapter(mijnAdapter);
        mijnLijst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @SuppressLint("LongLogTag")
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                if(position == 0) {
                    Intent mijnIntent = new Intent(view.getContext(), Modelpagina.class);
                    Log.d("Position clicked op merkpagina: ","1");
                    mijnIntent.putExtra("merkId",1);
                    startActivityForResult(mijnIntent,0);
                }
                if(position == 1) {
                    Intent mijnIntent = new Intent(view.getContext(), Modelpagina.class);
                    Log.d("Position clicked op merkpagina: ","2");
                    mijnIntent.putExtra(":merkId",2);
                    startActivityForResult(mijnIntent,1);
                }
                if(position == 2) {
                    Intent mijnIntent = new Intent(view.getContext(), Modelpagina.class);
                    Log.d("Position clicked op merkpagina: ","3");
                    mijnIntent.putExtra("merkId",3);
                    startActivityForResult(mijnIntent,2);
                }
            }
        });
    }
}