package com.example.werkstuk;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.werkstuk.adapter.ModelLijstAdapter;
import com.example.werkstuk.db.ApplicatieDatabase;
import com.example.werkstuk.db.entities.Model;

import java.util.List;

public class Zoekpagina extends AppCompatActivity {
    //int toonDeJuisteAuto = 0;
    private ModelLijstAdapter mijnAdapter;
    private ListView mijnLijst;
    private List<Model> alleModellen;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zoekpagina);

        toonDeGepasteModellen();
    }

    public void toonDeGepasteModellen() {
        Log.d("Voer uit: ","toonDeGepasteModellen");
        Thread mijnThread = new Thread(new Runnable() {

            @Override
            public void run() {
                //Lezen
                alleModellen = ApplicatieDatabase.getDatabase(Zoekpagina.super.getApplicationContext()).getModelDao().getAlleModellen();

                for (Model huidigModel : alleModellen) {
                    Log.d("Modeltypes: ", huidigModel.getModelType());
                    Log.d("ModelId: ", String.valueOf(huidigModel.getId()));
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        vullijstop(alleModellen);
                    }
                });



            }
        });
        mijnThread.start();

        EditText search = (EditText)findViewById(R.id.txtZoekbalk);
        Log.d("addTextChangedListener"," Uitgevoerd");
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Log.d("onTextChanged"," Uitgevoerd");
                if(getText().toString().equals("%%")){
                    Log.d("Null"," Geen tekst");
                    toonDeGepasteModellen();
                }else {
                    Log.d("getText in else",getText().toString());
                    toonDeGepasteModellenBijHetTypenInSearchbar(getText());
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public void toonDeGepasteModellenBijHetTypenInSearchbar(final String zoekbar) {
        Log.d("Voer uit: ","toonDeGepasteModellenBijTypen");
        Thread mijnThread = new Thread(new Runnable() {

            @Override
            public void run() {
                //Lezen
                alleModellen = ApplicatieDatabase.getDatabase(Zoekpagina.super.getApplicationContext()).getModelDao().getModelBijModeltype(zoekbar);

                for (Model huidigModel : alleModellen) {
                    Log.d("Modeltypes: ", huidigModel.getModelType());
                    Log.d("ModelId: ", String.valueOf(huidigModel.getId()));
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        vullijstop(alleModellen);
                    }
                });



            }
        });
        mijnThread.start();
    }

    @SuppressLint("LongLogTag")
    public String getText(){
        textView = (TextView) findViewById(R.id.txtZoekbalk);
        final String text = "%"+textView.getText().toString()+"%";
        Log.d("Dit is getyped in de searchbar ",text);
        return text;
    }

    public void vullijstop(final List<Model> alleModellen) {

        mijnAdapter = new ModelLijstAdapter(this, alleModellen);
        mijnLijst = findViewById(R.id.lstZoeken);
        mijnLijst.setAdapter(mijnAdapter);

        mijnLijst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                Model mijnGekozenModel = (Model) parent.getItemAtPosition(position);
                Log.d("Aangeklikt id",String.valueOf(mijnGekozenModel.getId()));
                Intent mijnIntent = new Intent(view.getContext(), Detailpagina.class);
                mijnIntent.putExtra("ModelId", mijnGekozenModel.getId());
                startActivity(mijnIntent);
            }
        });



    }



}