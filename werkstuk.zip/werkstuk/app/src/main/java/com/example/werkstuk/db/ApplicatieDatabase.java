package com.example.werkstuk.db;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.werkstuk.R;
import com.example.werkstuk.db.dao.AutogarageDao;
import com.example.werkstuk.db.dao.MerkDao;
import com.example.werkstuk.db.dao.ModelDao;
import com.example.werkstuk.db.entities.Autogarage;
import com.example.werkstuk.db.entities.Merk;
import com.example.werkstuk.db.entities.Model;

@Database(entities = {Autogarage.class, Merk.class, Model.class}, version = 2)
public abstract class ApplicatieDatabase extends RoomDatabase {
    private static ApplicatieDatabase mijnSingleton;
    //Dao's relateren
    public abstract AutogarageDao getAutogarageDao();
    public abstract MerkDao getMerkDao();
    public abstract ModelDao getModelDao();


    public static ApplicatieDatabase getDatabase(Context context) {
        if (mijnSingleton == null) {
            //Maak de database effectief aan
            mijnSingleton= Room.databaseBuilder(context.getApplicationContext(),
                    ApplicatieDatabase.class,"testdatabase").addCallback(new Callback() {
                @Override
                public void onCreate(@NonNull SupportSQLiteDatabase db) {

                    db.execSQL("INSERT INTO Autogarage (id,naam,telefoonnummer,adres) VALUES ('1','Luxury cars',0412334567,'denes.van.roy@student.ehb.be')");

                    db.execSQL("INSERT INTO Merk (merkId,merkNaam,slogan,merkFoto) VALUES (1,'Ferrari','Only those who dare, truly live',"+ R.drawable.ferrari_logo+")");
                    db.execSQL("INSERT INTO Merk (merkId,merkNaam,slogan,merkFoto) VALUES (2,'Lamborghini','We are not super cars. We are Lamborghini',"+ R.drawable.lamborghini_logo+")");

                    db.execSQL("INSERT INTO Model (id,modelType,uitrusting,merkId,foto) VALUES (1,'Ferrari Portofino','3.9L Ferrari F154BD V8',1,"+ R.drawable.ferrariportofino+")");
                    db.execSQL("INSERT INTO Model (id,modelType,uitrusting,merkId,foto) VALUES (2,'Ferrari F8 Tributo','3,9-liter V8',1,"+ R.drawable.ferrarif8_tributo+")");
                    db.execSQL("INSERT INTO Model (id,modelType,uitrusting,merkId,foto) VALUES (3,'Ferrari 488 GTB','3,9-liter V8',1,"+ R.drawable.ferrari488_gtb+")");

                    db.execSQL("INSERT INTO Model (id,modelType,uitrusting,merkId,foto) VALUES (4,'Lamborghini Aventador','6498 cc 60° V12',2,"+ R.drawable.aventador+")");



                    super.onCreate(db);
                }





                @Override
                public void onOpen(@NonNull SupportSQLiteDatabase db) {
                    Log.d("Database geopend","De databank werd geopend.");
                    super.onOpen(db);


                }
            }).addMigrations(new Migration(1,2) {
                @Override
                public void migrate(@NonNull SupportSQLiteDatabase database) {
                    Log.d("Databasemigratie","We zijn overgegaan van versie 1 naar versie 2 van de database.");
                }
            }).addMigrations(new Migration(2,3) {
                @Override
                public void migrate(@NonNull SupportSQLiteDatabase database) {
                    Log.d("Databasemigratie","We zijn overgegaan van versie 2 naar versie 3 van de database.");
                }
            }).build();
        }
        return mijnSingleton;
    }

    protected ApplicatieDatabase() {
        super();
    }

}
