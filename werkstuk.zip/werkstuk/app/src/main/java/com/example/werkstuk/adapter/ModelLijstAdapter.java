package com.example.werkstuk.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import com.example.werkstuk.R;
import com.example.werkstuk.db.entities.Model;

public class ModelLijstAdapter extends ArrayAdapter<Model> {
    public ModelLijstAdapter(Context context, List<Model> objects) {
        super(context, -1, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater mijnLayoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mijnListViewItemView = mijnLayoutInflater.inflate(R.layout.modellistitem, parent, false);

        //TextView lblModelId = (TextView)mijnListViewItemView.findViewById(R.id.lblModelId);
        TextView lblModel = (TextView)mijnListViewItemView.findViewById(R.id.lblModel);
        TextView lblUitrusting = (TextView)mijnListViewItemView.findViewById(R.id.lblUitrusting);
        ImageView imageViewModel = (ImageView) mijnListViewItemView.findViewById(R.id.imageViewModel);

        Model weerTeGevenModel = this.getItem(position);

        //lblModelId.setText(Integer.toString(weerTeGevenModel.getModelId()));
        lblModel.setText(weerTeGevenModel.getModelType());
        lblUitrusting.setText(weerTeGevenModel.getUitrusting());
        imageViewModel.setImageResource(weerTeGevenModel.getFoto());

        return mijnListViewItemView;
    }


}


