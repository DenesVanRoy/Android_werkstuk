package com.example.werkstuk;

import androidx.appcompat.app.AppCompatActivity;

//import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

import com.example.werkstuk.adapter.ModelLijstAdapter;
import com.example.werkstuk.db.ApplicatieDatabase;
import com.example.werkstuk.db.entities.Model;


public class Modelpagina extends AppCompatActivity {

    private ModelLijstAdapter mijnAdapter;
    private ListView mijnLijst;
    private List<Model> alleModellen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modelpagina);

        toonDeGepasteModellen();
    }

    public void toonDeGepasteModellen() {
        Log.d("Voer uit: ", "toonDeGepasteModellen");
        Thread mijnThread = new Thread(new Runnable() {

            @Override
            public void run() {
                Bundle x = getIntent().getExtras();
                int merkId = x.getInt("merkId");
                Log.d("merkId op modelpagina", x.toString());
                //Lezen
                alleModellen = ApplicatieDatabase.getDatabase(Modelpagina.super.getApplicationContext()).getModelDao().getAlleModellenBijGekozenMerk(merkId);

                for (Model huidigModel : alleModellen) {
                    Log.d("Modeltypes: ", huidigModel.getModelType());
                    Log.d("ModelId: ", String.valueOf(huidigModel.getId()));
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        vullijstop(alleModellen);
                    }
                });


            }
        });
        mijnThread.start();

    }

    public void vullijstop(final List<Model> alleModellen) {
        mijnAdapter = new ModelLijstAdapter(this, alleModellen);
        mijnLijst = findViewById(R.id.lstModellen);
        mijnLijst.setAdapter(mijnAdapter);

        mijnLijst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                mijnLijst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long l) {
                        Model mijnGekozenModel = (Model) parent.getItemAtPosition(position);
                        Log.d("Aangeklikt id",String.valueOf(mijnGekozenModel.getId()));
                        Intent mijnIntent = new Intent(view.getContext(), Detailpagina.class);
                        mijnIntent.putExtra("id", mijnGekozenModel.getId());
                        startActivity(mijnIntent);
                    }
                });

            }
        });


    }

}
