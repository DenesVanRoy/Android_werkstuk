package com.example.werkstuk.db.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.werkstuk.db.entities.Autogarage;
import com.example.werkstuk.db.entities.Merk;

import java.util.List;

@Dao
public interface AutogarageDao {

    @Query("SELECT * FROM Autogarage")
    public List<Autogarage> getAlleAutogarages();

    @Query("SELECT * FROM Autogarage WHERE id =:id")
    public Autogarage getAutogarageById(int id);

    @Insert
    public long voegNieuweAutogarageToe(Autogarage nieuweAutogarage);

}
