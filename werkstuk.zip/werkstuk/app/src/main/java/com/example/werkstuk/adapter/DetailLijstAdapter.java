package com.example.werkstuk.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.werkstuk.R;
import com.example.werkstuk.db.entities.Model;

import java.util.List;

public class DetailLijstAdapter extends ArrayAdapter<Model> {
        public DetailLijstAdapter(Context context, List<Model> objects) {
                super(context, -1, objects);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
                LayoutInflater mijnLayoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View mijnListViewItemView = mijnLayoutInflater.inflate(R.layout.detaillistitem, parent, false);

                //TextView lblModelId = (TextView)mijnListViewItemView.findViewById(R.id.lblModelId);
                TextView txtModeltyp = (TextView)mijnListViewItemView.findViewById(R.id.txtModeltyp);
                TextView txtUitrusting = (TextView)mijnListViewItemView.findViewById(R.id.txtUitrusting);
                ImageView imageViewMod = (ImageView) mijnListViewItemView.findViewById(R.id.imageViewMod);

                Model weerTeGevenModel = this.getItem(position);

                //lblModelId.setText(Integer.toString(weerTeGevenModel.getModelId()));
                txtModeltyp.setText(weerTeGevenModel.getModelType());
                txtUitrusting.setText(weerTeGevenModel.getUitrusting());
                imageViewMod.setImageResource(weerTeGevenModel.getFoto());

                return mijnListViewItemView;
        }
}