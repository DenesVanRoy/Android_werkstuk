package com.example.werkstuk.db.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

import com.example.werkstuk.db.entities.Merk;

@Dao
public interface MerkDao {

    @Query("SELECT * FROM Merk")
    public List<Merk> getAlleMerken();

    @Query("SELECT * FROM Merk WHERE merkId =:id")
    public Merk getAutoById(int id);

    @Insert
    public long voegNieuwMerkToe(Merk nieuweAuto);

}