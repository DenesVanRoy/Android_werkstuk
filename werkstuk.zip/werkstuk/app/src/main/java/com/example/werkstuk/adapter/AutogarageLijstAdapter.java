package com.example.werkstuk.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.werkstuk.R;
import com.example.werkstuk.db.entities.Autogarage;

import java.util.List;

public class AutogarageLijstAdapter extends ArrayAdapter<Autogarage> {
    public AutogarageLijstAdapter(Context context, List<Autogarage> objects) {
        super(context, -1, objects);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater mijnLayoutInflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View mijnListViewItemView = mijnLayoutInflater.inflate(R.layout.navigatielistitem, parent, false);

        TextView txtGaragenaam = (TextView)mijnListViewItemView.findViewById(R.id.txtGaragenaam);


        Autogarage weerTeGevenAutogarage = this.getItem(position);

        txtGaragenaam.setText(weerTeGevenAutogarage.getNaam());

        return mijnListViewItemView;
    }
}